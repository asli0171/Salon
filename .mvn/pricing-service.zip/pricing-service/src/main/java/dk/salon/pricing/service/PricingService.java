package dk.salon.pricing.service;

import dk.salon.pricing.model.PricingRequest;
import dk.salon.pricing.model.PricingResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class PricingService {

    @Value("${pricing.premium.surcharge:0.20}")
    private double premiumSurcharge;

    @Value("${pricing.colour.surcharge:50.0}")
    private double colourSurcharge;

    @Value("${pricing.treatment.surcharge:30.0}")
    private double treatmentSurcharge;

    @Value("${pricing.long.duration.threshold:75}")
    private int longDurationThreshold;

    @Value("${pricing.long.duration.surcharge:50.0}")
    private double longDurationSurcharge;

    public PricingResponse calculate(PricingRequest request) {
        double price = request.getBasePrice();
        StringBuilder breakdown = new StringBuilder();
        breakdown.append("Basispris: ").append(price).append(" kr");

        // Premium frisør tillæg (+20%)
        if (request.isPremiumHairdresser()) {
            double surcharge = Math.round(price * premiumSurcharge);
            price += surcharge;
            breakdown.append(" + premium tillæg: ").append(surcharge).append(" kr");
        }

        // Servicetype-tillæg
        if (request.getServiceType() != null) {
            String type = request.getServiceType().toLowerCase();

            if (type.contains("farve") || type.contains("colour") || type.contains("color")) {
                price += colourSurcharge;
                breakdown.append(" + farvetillæg: ").append(colourSurcharge).append(" kr");
            }

            if (type.contains("behandling") || type.contains("treatment")) {
                price += treatmentSurcharge;
                breakdown.append(" + behandlingstillæg: ").append(treatmentSurcharge).append(" kr");
            }
        }

        // Lang behandling tillæg (over threshold minutter)
        if (request.getDurationMinutes() > longDurationThreshold) {
            price += longDurationSurcharge;
            breakdown.append(" + lang behandling: ").append(longDurationSurcharge).append(" kr");
        }

        double finalPrice = Math.round(price);
        breakdown.append(" = ").append(finalPrice).append(" kr");

        return new PricingResponse(finalPrice, breakdown.toString());
    }
}
